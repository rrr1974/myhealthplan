package model;

/*@Data
@Entity
@Table(name="Patient")*/
public class Patient {
	
	/* @Column(name="pname") */
	private String pname;
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(generator = "Patient")
	 * 
	 * @SequenceGenerator(name = "patient",sequenceName = "patient_seq")
	 * 
	 * @Column(name="pid")
	 */
	private String subscriberId;
	
	/* @Column(name="pdate") */
	private String pdate;
	
	/* @Column(name="gender") */
	private String gender;
	
	private String period;
	
	private String status;

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getPdate() {
		return pdate;
	}

	public void setPdate(String pdate) {
		this.pdate = pdate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(String subscriberId) {
		this.subscriberId = subscriberId;
	}
	
	
	
	

}
