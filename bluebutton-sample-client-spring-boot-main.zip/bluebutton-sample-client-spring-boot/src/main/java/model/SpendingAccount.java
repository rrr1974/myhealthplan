package model;

/*import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;
*/
/*@Data
@Entity
@Table(name="hsa")*/
public class SpendingAccount {
	
	/*
	 * @Id
	 * 
	 * @GeneratedValue(generator = "Hsa")
	 * 
	 * @SequenceGenerator(name = "hsa",sequenceName = "hsa_seq")
	 * 
	 * @Column(name="pid")
	 */
	private String id;
	
	private String accountType;
	
	/* @Column(name="pname") */
	private String accountHolder;
	
	private String fromDate;
	private String toDate;
	
	private String election;
	
	/* @Column(name="spending") */
	private String spending;
	
	/* @Column(name="balance") */
	private String balance;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getElection() {
		return election;
	}

	public void setElection(String election) {
		this.election = election;
	}

	public String getSpending() {
		return spending;
	}

	public void setSpending(String spending) {
		this.spending = spending;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	

}
